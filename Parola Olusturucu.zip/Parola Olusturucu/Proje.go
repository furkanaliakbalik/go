package main

import (
	"fmt"
	"math/rand"
	"os"
	"time"
)

// GeneratePassword fonksiyonu, belirtilen uzunlukta ve seviyede rastgele bir şifre oluşturur.
func GeneratePassword(uzunluk, seviye int) string {
	chars := "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

	// Seviyeye bağlı olarak rakamları ekle
	if seviye >= 1 {
		chars += "0123456789"
	}

	// Seviyeye bağlı olarak özel karakterleri ekle
	if seviye >= 2 {
		chars += "!@#$%^&*()-=_+[]{}|;:'\",.<>/?"
	}

	rand.Seed(time.Now().UnixNano())

	var password string
	// Belirtilen uzunlukta rastgele bir şifre oluştur
	for i := 0; i < uzunluk; i++ {
		password += string(chars[rand.Intn(len(chars))])
	}

	return password
}

func main() {
	for {
		fmt.Println("--------------------\nPassword Generator\n---------------------")

		var uzunluk int
		fmt.Print("Uzunluk: ")
		fmt.Scan(&uzunluk)

		var seviye int
		// Kullanıcıdan seviye seçmesi isteniyor
		fmt.Println("(1=Standart), (2=random) ex. 1: ")
		fmt.Print("Seviye: ")
		fmt.Scan(&seviye)

		password := GeneratePassword(uzunluk, seviye)
		fmt.Println("\nYour password is:", password)

		// Başka bir şifre oluşturup oluşturmayacakları soruluyor
		var choice string
		fmt.Print("Would you like to generate another password? (yes/no): ")
		fmt.Scan(&choice)

		if choice != "yes" {
			break // Kullanıcı başka bir şifre oluşturmak istemezse döngüden çık
		}
	}

	os.Exit(0)
}
