package main

import (
	"bufio"
	"fmt"
	"os"
	"time"
)

// TersCevir fonksiyonu, aldığı metni ters çevirip geri döndürür.
func TersCevir(metin string) string {
	runes := []rune(metin)
	for i, j := 0, len(runes)-1; i < j; i, j = i+1, j-1 {
		runes[i], runes[j] = runes[j], runes[i]
	}
	return string(runes)
}

func main() {
	fmt.Println("\nGirilen Metni Tersten Yazan Programa Hoşgeldiniz... Exit 'x'")
	fmt.Println("***************************************************************")

	for {
		fmt.Print("Bir metin girin: ")
		scanner := bufio.NewScanner(os.Stdin)
		scanner.Scan()
		metin := scanner.Text()

		if metin == "x" {
			fmt.Println("by")
			time.Sleep(5 * time.Second) // Programın 5 saniye sonra kapanmasını sağlar
			break
		}

		tersMetin := TersCevir(metin)
		fmt.Println("Tersi:", tersMetin)
		fmt.Println("***************************************************************")
	}
}
