package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
)

func main() {
	scanner := bufio.NewScanner(os.Stdin)

	for {
		fmt.Print("\nEnter your name: ")
		if !scanner.Scan() {
			break
		}
		name := scanner.Text()

		fmt.Print("Enter your age: ")
		ageStr := ""
		for {
			if !scanner.Scan() {
				break
			}
			ageStr = scanner.Text()

			age, err := strconv.Atoi(ageStr)
			if err != nil {
				fmt.Print("Please enter a numerical value for age: ")
				continue
			}

			if age < 18 {
				difference := 18 - age
				fmt.Printf("Sorry %s, we cannot admit individuals under 18. Please come back in %d years.\n", name, difference)
				fmt.Println("**************************************************************************************************************")
			} else {
				fmt.Printf("Welcome, %s!\n", name)
				fmt.Println("**************************************************************************************************************")
			}
			break
		}
	}

	if err := scanner.Err(); err != nil {
		fmt.Println("Input error:", err)
	}
}
