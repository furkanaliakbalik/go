package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

func SayKelime(metin string) int {
	if metin == "" {
		return 0
	}

	words := strings.Fields(metin)
	return len(words)
}

func main() {
	// Türkçe karakterleri doğru bir şekilde göstermek için locale tanımlamamıza gerek yok

	fmt.Println("************************************************")
	fmt.Println("Kelime Sayacına Hoşgeldiniz")
	fmt.Println("************************************************")

	scanner := bufio.NewScanner(os.Stdin)

	for {
		fmt.Print("Metni girin: ")
		if !scanner.Scan() {
			break
		}
		metin := scanner.Text()

		kelimeSayisi := SayKelime(metin)

		fmt.Println("Girilen metindeki kelime sayısı:", kelimeSayisi)
		fmt.Println("************************************************")
	}

	if err := scanner.Err(); err != nil {
		fmt.Println("Okuma hatası:", err)
	}
}
